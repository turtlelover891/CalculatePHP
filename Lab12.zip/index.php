<!doctype HTML>

<html>
    <head>
        <title>Lab 9</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <?php
            include "header.php";
            include "navigation.php";
        ?>

        <div class="center">
            <p>Hello and welcome to LCCC</p>
        </div>

        <?php
            include "footer.php";
        ?>
    </body>
</html>