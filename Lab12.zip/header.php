<header>
    <h1>LCCC</h1>
</header>