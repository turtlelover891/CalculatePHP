<nav>
    <a href="index.php">Home</a>
    <a href="calculate.php">Calculator</a>
    <a href="chart.php">Chart</a>
</nav>