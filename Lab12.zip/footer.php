<footer>
    &copy; Sam Vlasenko
</footer>